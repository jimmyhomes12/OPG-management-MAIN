<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OPG_Management
 */

?>

</div><!-- #content -->

<!-- Footer -->
<footer>
    <div class="container">
        <div class="footer-columns">
            <div class="footer-column">
                <h3>QUICK LINKS</h3>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
                ?>
            </div>
            <div class="footer-column">
                <?php if (is_active_sidebar('footer-1')) : ?>
                    <?php dynamic_sidebar('footer-1'); ?>
                <?php else : ?>
                    <h3>CONTACT INFO</h3>
                    <p>123 Los Angeles Los Angeles, CA 90001 Suite 456</p>
                    <p>PHONE: (555) 555-1234</p>
                    <p>EMAIL: INFO@CREMMGMT.COM</p>
                    <p>HOURS: MON-FRI 9AM-5PM</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="footer-bottom">           
             <p class="copyright">&copy;<?php echo date('Y'); ?> <?php echo get_bloginfo('name'); ?>. All Rights Reserved.</p>
<div class="footer-logos">
                <img src="<?php echo get_template_directory_uri(); ?>/images/aagla.png" alt="AAGLA Logo">
                <img src="<?php echo get_template_directory_uri(); ?>/images/realtor.png" alt="Realtor Logo">
                <img src="<?php echo get_template_directory_uri(); ?>/images/car.png" alt="CAR Logo">
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>

</html>