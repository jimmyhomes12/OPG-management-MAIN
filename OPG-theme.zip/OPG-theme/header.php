<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OPG_Management
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header -->
<header>
    <div class="container">
        <div class="logo">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>">
                </a>
            <?php endif; ?>
        </div>
        <nav>
            <?php
            if (has_nav_menu('primary-menu')) {
                wp_nav_menu(array(
                    'theme_location' => 'primary-menu',
                    'menu_id'        => 'primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
            } else {
                // Default menu if no menu is assigned
                echo '<ul id="primary-menu">';
                echo '<li><a href="' . esc_url(home_url('/')) . '">HOME</a></li>';
                echo '<li><a href="' . esc_url(home_url('/owners')) . '">OWNERS</a></li>';
                echo '<li><a href="' . esc_url(home_url('/tenants')) . '">TENANTS</a></li>';
                echo '<li><a href="' . esc_url(home_url('/rentals')) . '">RENTALS</a></li>';
                echo '<li><a href="' . esc_url(home_url('/blog')) . '">BLOG</a></li>';
                echo '<li><a href="' . esc_url(home_url('/about-us')) . '">ABOUT US</a></li>';
                echo '<li><a href="' . esc_url(home_url('/contact')) . '">CONTACT</a></li>';
                echo '<li><a href="' . esc_url(home_url('/login')) . '">LOGIN</a></li>';
                echo '</ul>';
            }
            ?>
        </nav>
    </div>
</header>

<div id="content" class="site-content">
