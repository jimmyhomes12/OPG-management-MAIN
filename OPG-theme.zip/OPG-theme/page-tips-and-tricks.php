<?php
/**
 * Template Name: Tips and Tricks for Owners & Tenants
 *
 * This template displays helpful tips for property owners and tenants.
 *
 * @package OPG-theme
 */

get_header();
?>

<main id="primary" class="site-main">
    <section class="page-header" style="padding: 150px 0 50px; text-align: center; background-color: var(--light-gray);">
        <div class="container">
            <h1><?php the_title(); ?></h1>
            <?php if (get_the_content()) : ?>
                <div class="page-description">
                    <?php the_content(); ?>
                </div>
            <?php else : ?>
                <div class="page-description">
                    <p>Essential advice for both property owners and tenants to maintain a positive, productive relationship and get the most out of your property.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="tips-section" style="padding: 50px 0; background-color: #fff;">
        <div class="container">
            <h2>Top 10 Property Management Tips</h2>
            
            <div class="horizontal-scroll-wrapper">
                <div class="horizontal-scroll-container">
                    <div class="horizontal-scroll-content">
                        <?php
                        // Define the tips
                        $tips = array(
                    array(
                        'title' => 'Regular Maintenance Keeps Your Property Value High',
                        'content' => 'Performing regular maintenance checks prevents costly repairs and keeps your property in great condition, benefiting both owners and tenants.',
                        'image' => 'repair-maintenance.png',
                        'label' => 'Maintenance',
                    ),
                    array(
                        'title' => 'Communicate Effectively with Your Landlord or Tenant',
                        'content' => 'Clear, respectful communication helps address concerns quickly and ensures a smooth, professional relationship for both parties.',
                        'image' => 'comment.png',
                        'label' => 'Communication',
                    ),
                    array(
                        'title' => 'Understand Your Lease Agreement',
                        'content' => 'Before signing, take time to thoroughly read and understand all terms in your lease agreement to avoid future misunderstandings.',
                        'image' => 'rent-collection.png',
                        'label' => 'Legal',
                    ),
                    array(
                        'title' => 'Keep Detailed Records of Property Interactions',
                        'content' => 'Track all maintenance requests, payments, and communication to keep things organized and avoid disputes down the line.',
                        'image' => 'financial-reporting.png',
                        'label' => 'Organization',
                    ),
                    array(
                        'title' => 'Set Clear Expectations for Rent Payments',
                        'content' => 'Ensure tenants know when rent is due, accepted payment methods, and any late fee policies to keep everything running smoothly.',
                        'image' => 'rent-collection.png',
                        'label' => 'Payments',
                    ),
                    array(
                        'title' => 'Use Technology to Simplify Property Management',
                        'content' => 'Leverage property management software to handle payments, maintenance requests, and communication more efficiently.',
                        'image' => 'financial-reporting.png',
                        'label' => 'Technology',
                    ),
                    array(
                        'title' => 'Protect Your Property with Proper Insurance',
                        'content' => 'Ensure your property is fully covered with the right insurance, including liability and property damage coverage for peace of mind.',
                        'image' => 'expenses.png',
                        'label' => 'Insurance',
                    ),
                    array(
                        'title' => 'Respect Tenants\' Privacy and Comfort',
                        'content' => 'Respecting tenants\' privacy fosters trust, and maintaining a comfortable living environment encourages longer-term tenants and fewer vacancies.',
                        'image' => 'apartment-turnover-service.png',
                        'label' => 'Privacy',
                    ),
                    array(
                        'title' => 'Respond Promptly to Maintenance Requests',
                        'content' => 'Addressing maintenance issues promptly enhances tenant satisfaction and prevents minor problems from becoming costly repairs.',
                        'image' => 'repair-maintenance.png',
                        'label' => 'Response',
                    ),
                    array(
                        'title' => 'Stay Informed About Local Rental Laws',
                        'content' => 'Being aware of local rental regulations helps you remain compliant and avoid potential legal issues that could affect your business.',
                        'image' => 'realtor.png',
                        'label' => 'Compliance',
                    ),
                );
                
                // Display the tips as cards
                foreach ($tips as $index => $tip) {
                    $args = array(
                        'image_url' => get_template_directory_uri() . '/images/' . $tip['image'],
                        'alt_text' => 'Tip ' . ($index + 1),
                        'label' => $tip['label'],
                        'title' => $tip['title'],
                        'content' => $tip['content'],
                    );
                    get_template_part('template-parts/card', null, $args);
                }
                ?>
                    </div>
                </div>
                
                <!-- Scroll Controls -->
                <div class="scroll-controls">
                    <button class="scroll-btn scroll-prev"><i class="fa fa-chevron-left"></i></button>
                    <button class="scroll-btn scroll-next"><i class="fa fa-chevron-right"></i></button>
                </div>
            </div>
            
            <!-- Latest News Section -->
            <div class="latest-news-section" style="margin-top: 80px;">
                <h2>Latest Property Management News</h2>
                <div class="news-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px; margin-top: 30px;">
                    <?php
                    // Get the latest 3 posts
                    $latest_posts = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => 3,
                        'orderby' => 'date',
                        'order' => 'DESC'
                    ));

                    if ($latest_posts->have_posts()) :
                        while ($latest_posts->have_posts()) : $latest_posts->the_post();
                    ?>
                        <div class="news-item" style="background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); overflow: hidden;">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="news-image" style="height: 200px; overflow: hidden;">
                                    <?php the_post_thumbnail('medium', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                                </div>
                            <?php endif; ?>
                            <div class="news-content" style="padding: 20px;">
                                <h3 style="margin-top: 0; margin-bottom: 10px; font-size: 1.2rem;">
                                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: var(--primary-color, #003366);">
                                        <?php the_title(); ?>
                                    </a>
                                </h3>
                                <div class="news-meta" style="font-size: 0.9rem; color: #666; margin-bottom: 15px;">
                                    <?php echo get_the_date(); ?> | <?php the_category(', '); ?>
                                </div>
                                <div class="news-excerpt" style="margin-bottom: 15px; line-height: 1.6;">
                                    <?php the_excerpt(); ?>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="read-more" style="display: inline-block; color: var(--secondary-color, #0056b3); font-weight: 600;">
                                    Read More →
                                </a>
                            </div>
                        </div>
                    <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                    ?>
                        <div class="no-posts" style="grid-column: 1 / -1; text-align: center;">
                            <p>No news articles found. Check back soon for updates!</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div style="text-align: center; margin-top: 40px;">
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn secondary-btn" style="display: inline-block; background-color: var(--secondary-color, #0056b3); color: white; padding: 10px 25px; border-radius: 4px; text-decoration: none; font-weight: 600;">View All News</a>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 80px;">
                <h3>Need More Advice?</h3>
                <p>Contact our property management team for personalized guidance on managing your property or navigating tenant issues.</p>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn primary-btn">Contact Us</a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
