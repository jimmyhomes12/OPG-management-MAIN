<?php
/**
 * Template part for displaying card components
 *
 * @package OPG-theme
 */

// Default values
$defaults = array(
    'image_url' => '',
    'alt_text' => '',
    'label' => 'Featured',
    'title' => '',
    'content' => '',
    'link' => '',
);

// Merge provided args with defaults
$args = wp_parse_args($args, $defaults);
?>

<article class="card">
  <div class="card__wrapper">
    <?php if (!empty($args['image_url'])) : ?>
    <figure class="card__feature">
      <img src="<?php echo esc_url($args['image_url']); ?>" class="card__img" alt="<?php echo esc_attr($args['alt_text']); ?>" width="275" height="240">
    </figure>
    <?php endif; ?>

    <div class="card__box">
      <header class="card__item card__header">
        <?php if (!empty($args['label'])) : ?>
        <h6 class="card__item card__item--small card__label"><?php echo esc_html($args['label']); ?></h6>
        <?php endif; ?>
        
        <?php if (!empty($args['title'])) : ?>
        <h2 class="card__item card__item--small card__title"><?php echo esc_html($args['title']); ?></h2>
        <?php endif; ?>
      </header>

      <hr class="card__item card__divider">

      <section class="card__item card__body">
        <?php if (!empty($args['content'])) : ?>
        <p><?php echo esc_html($args['content']); ?></p>
        <?php endif; ?>
      </section>
    </div>
  </div>
</article>
