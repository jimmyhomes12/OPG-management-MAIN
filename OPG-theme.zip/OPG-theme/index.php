<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package OPG_Management
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <?php
        if (have_posts()) :
            
            while (have_posts()) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h2 class="entry-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="entry-meta">
                            <?php
                            opg_management_posted_on();
                            opg_management_posted_by();
                            ?>
                        </div>
                    </header>

                    <div class="entry-content">
                        <?php
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('medium');
                        }
                        
                        the_excerpt();
                        ?>
                        <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
                    </div>
                </article>
                <?php
            endwhile;

            the_posts_pagination(array(
                'mid_size'  => 2,
                'prev_text' => __('Previous', 'opg-management'),
                'next_text' => __('Next', 'opg-management'),
            ));

        else :
            ?>
            <p><?php esc_html_e('No posts found.', 'opg-management'); ?></p>
            <?php
        endif;
        ?>
    </div>
</main>

<?php
get_sidebar();
get_footer();
?>
