<?php
/**
 * Template Name: Cards Demo
 *
 * This template demonstrates the card component with some sample content.
 *
 * @package OPG-theme
 */

get_header();
?>

<main id="primary" class="site-main">
    <section class="page-header" style="padding: 150px 0 50px; text-align: center; background-color: var(--light-gray);">
        <div class="container">
            <h1><?php the_title(); ?></h1>
            <?php if (get_the_content()) : ?>
                <div class="page-description">
                    <?php the_content(); ?>
                </div>
            <?php else : ?>
                <div class="page-description">
                    <p>This page demonstrates the usage of our custom card component.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="cards-demo" style="padding: 50px 0; background-color: #fff;">
        <div class="container">
            <h2>Featured Properties</h2>
            
            <div class="cards-container">
                <?php
                // Example 1: Ocean Waves Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/banner-1.jpg.jpeg',
                    'alt_text' => 'Luxury Property',
                    'label' => 'Featured',
                    'title' => 'Luxury Beachfront Property',
                    'content' => 'Experience luxury living with breathtaking ocean views in this exclusive beachfront property.',
                );
                get_template_part('template-parts/card', null, $args);
                
                // Example 2: Modern Architecture Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/about-us.jpg.jpeg',
                    'alt_text' => 'Modern Architecture',
                    'label' => 'New Listing',
                    'title' => 'Modern Urban Living',
                    'content' => 'Sleek design meets urban convenience in this modern property located in the heart of the city.',
                );
                get_template_part('template-parts/card', null, $args);
                
                // Example 3: Apartment Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/How%20to%20Minimize%20ExpensesFor%20Landlords%20andTenants.jpg.jpeg',
                    'alt_text' => 'Apartment Living',
                    'label' => 'Special Offer',
                    'title' => 'Cozy Downtown Apartment',
                    'content' => 'Perfectly positioned apartment offering convenience and comfort in a vibrant neighborhood.',
                );
                get_template_part('template-parts/card', null, $args);
                ?>
            </div>
            
            <h2 style="margin-top: 50px;">Management Services</h2>
            
            <div class="cards-container">
                <?php
                // Example 4: Property Management Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/BEYOND%20THE%205%20BASIC%20STRATEGIES%20TO%20MANAGE%20REPAIR%20AND%20MAINTENANCE%20EXPENSES.jpg.jpeg',
                    'alt_text' => 'Property Management',
                    'label' => 'Service',
                    'title' => 'Full-Service Management',
                    'content' => 'Comprehensive property management services for residential and commercial properties.',
                );
                get_template_part('template-parts/card', null, $args);
                
                // Example 5: Tenant Placement Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/apartment-turnover-service.png',
                    'alt_text' => 'Tenant Placement',
                    'label' => 'Service',
                    'title' => 'Tenant Placement',
                    'content' => 'Expert tenant screening and placement services to find the right fit for your property.',
                );
                get_template_part('template-parts/card', null, $args);
                
                // Example 6: Maintenance Card
                $args = array(
                    'image_url' => get_template_directory_uri() . '/images/repair-maintenance.png',
                    'alt_text' => 'Maintenance Services',
                    'label' => 'Service',
                    'title' => 'Maintenance & Repairs',
                    'content' => 'Prompt and reliable maintenance services to keep your property in excellent condition.',
                );
                get_template_part('template-parts/card', null, $args);
                ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
