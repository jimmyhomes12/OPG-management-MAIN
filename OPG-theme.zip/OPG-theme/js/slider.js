/**
 * Hero Slider functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get all slides and dots
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    
    if (slides.length === 0 || dots.length === 0) return;
    
    let currentSlide = 0;
    let slideInterval;
    
    // Initialize: Set first slide and dot as active
    function initSlider() {
        slides[0].style.opacity = 1;
        dots[0].classList.add('active');
        
        // Start the automatic slideshow
        startSlideshow();
    }
    
    // Go to specified slide
    function goToSlide(n) {
        // Hide all slides
        slides.forEach(slide => {
            slide.style.opacity = 0;
            slide.style.zIndex = -1;
        });
        
        // Remove active class from all dots
        dots.forEach(dot => {
            dot.classList.remove('active');
        });
        
        // Show the target slide
        slides[n].style.opacity = 1;
        slides[n].style.zIndex = 0;
        
        // Add active class to current dot
        dots[n].classList.add('active');
        
        // Update current slide index
        currentSlide = n;
    }
    
    // Next slide
    function nextSlide() {
        let next = currentSlide + 1;
        if (next >= slides.length) next = 0;
        goToSlide(next);
    }
    
    // Previous slide
    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 0) prev = slides.length - 1;
        goToSlide(prev);
    }
    
    // Start automatic slideshow
    function startSlideshow() {
        slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
    }
    
    // Stop automatic slideshow
    function stopSlideshow() {
        clearInterval(slideInterval);
    }
    
    // Click events for dots
    dots.forEach((dot, index) => {
        dot.addEventListener('click', function() {
            stopSlideshow();
            goToSlide(index);
            startSlideshow();
        });
    });
    
    // Initialize the slider
    initSlider();
});
