/**
 * Horizontal auto-scrolling carousel for cards
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get all horizontal scroll containers on the page
    const scrollContainers = document.querySelectorAll('.horizontal-scroll-container');
    
    scrollContainers.forEach(container => {
        const scrollContent = container.querySelector('.horizontal-scroll-content');
        const cardWidth = container.querySelector('.card') ? container.querySelector('.card').offsetWidth : 0;
        
        if (!scrollContent || !cardWidth) return;
        
        // Clone items for infinite effect
        const itemsToClone = scrollContent.children.length;
        
        // Clone the first set of items and append them to the end
        for (let i = 0; i < itemsToClone; i++) {
            const clone = scrollContent.children[i].cloneNode(true);
            scrollContent.appendChild(clone);
        }
        
        // Animation variables
        let currentPosition = 0;
        const gap = 20; // Gap between cards
        const scrollSpeed = 1; // Pixels per frame
        const totalWidth = (cardWidth + gap) * itemsToClone;
        
        // Pause on hover
        let isPaused = false;
        
        container.addEventListener('mouseenter', () => {
            isPaused = true;
        });
        
        container.addEventListener('mouseleave', () => {
            isPaused = false;
        });
        
        // Manual controls
        const prevButton = container.querySelector('.scroll-prev');
        const nextButton = container.querySelector('.scroll-next');
        
        if (prevButton) {
            prevButton.addEventListener('click', () => {
                currentPosition += (cardWidth + gap) * 3;
                if (currentPosition > 0) {
                    currentPosition = -totalWidth + (cardWidth + gap) * 3;
                }
                scrollContent.style.transform = `translateX(${currentPosition}px)`;
            });
        }
        
        if (nextButton) {
            nextButton.addEventListener('click', () => {
                currentPosition -= (cardWidth + gap) * 3;
                if (currentPosition < -totalWidth) {
                    currentPosition = -(cardWidth + gap) * 3;
                }
                scrollContent.style.transform = `translateX(${currentPosition}px)`;
            });
        }
        
        // Animation function
        function animateScroll() {
            if (!isPaused) {
                currentPosition -= scrollSpeed;
                
                // Reset position when scrolled one full set
                if (currentPosition < -totalWidth) {
                    currentPosition = 0;
                }
                
                scrollContent.style.transform = `translateX(${currentPosition}px)`;
            }
            
            requestAnimationFrame(animateScroll);
        }
        
        // Start animation
        animateScroll();
    });
});
