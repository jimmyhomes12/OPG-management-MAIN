<?php
/**
 * Template Name: Card Template Documentation
 *
 * This template provides documentation for how to use the card component.
 *
 * @package OPG-theme
 */

get_header();
?>

<main id="primary" class="site-main">
    <section class="page-header" style="padding: 150px 0 50px; text-align: center; background-color: var(--light-gray);">
        <div class="container">
            <h1>Card Component Documentation</h1>
            <div class="page-description">
                <p>This page provides documentation on how to use the card component in your WordPress content.</p>
            </div>
        </div>
    </section>

    <section class="docs-section" style="padding: 50px 0; background-color: #fff;">
        <div class="container">
            <h2>Using Cards in WordPress</h2>
            
            <div style="margin-bottom: 40px;">
                <h3>Method 1: Using Template Parts in PHP</h3>
                <p>For developers, you can use the template part directly in your theme files:</p>
                
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow: auto;">
&lt;?php
// Example 1: Basic usage
$args = array(
    'image_url' => get_template_directory_uri() . '/images/example.jpg',
    'alt_text'  => 'Example Image',
    'label'     => 'Featured',
    'title'     => 'Card Title',
    'content'   => 'This is the card content.',
);
get_template_part('template-parts/card', null, $args);
?&gt;
                </pre>
            </div>
            
            <div style="margin-bottom: 40px;">
                <h3>Method 2: Using Shortcodes in Content</h3>
                <p>For editors and content creators, you can use shortcodes in your pages and posts:</p>
                
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow: auto;">
# Single Card
[opg_card image="<?php echo esc_url(get_template_directory_uri() . '/images/banner-1.jpg.jpeg'); ?>" 
    label="Featured" 
    title="Card Title" 
    content="Card content goes here"]

# Multiple Cards in Container
[opg_cards_container]
    [opg_card image="<?php echo esc_url(get_template_directory_uri() . '/images/banner-1.jpg.jpeg'); ?>" 
        label="Card 1" 
        title="First Card" 
        content="First card content"]
        
    [opg_card image="<?php echo esc_url(get_template_directory_uri() . '/images/about-us.jpg.jpeg'); ?>" 
        label="Card 2" 
        title="Second Card" 
        content="Second card content"]
[/opg_cards_container]
                </pre>
            </div>
            
            <h2>Shortcode Parameters</h2>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 40px;">
                <thead>
                    <tr style="background-color: #f5f5f5;">
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Parameter</th>
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Description</th>
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Default</th>
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Required</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><code>image</code></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">URL of the image to display</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Empty</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">No</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><code>alt</code></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Alt text for the image</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Empty (falls back to title)</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">No</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><code>label</code></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Small label text that appears above the title</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">"Featured"</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">No</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><code>title</code></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Main title of the card</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Empty</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">No</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><code>content</code></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Main content text for the card</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">Empty</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">No</td>
                    </tr>
                </tbody>
            </table>
            
            <h2>Live Examples</h2>
            
            <div style="margin-bottom: 20px;">
                <h3>Example 1: Single Card</h3>
                <?php 
                // Display a single card
                echo do_shortcode('[opg_card 
                    image="' . get_template_directory_uri() . '/images/banner-1.jpg.jpeg' . '" 
                    label="Example" 
                    title="Single Card Example" 
                    content="This is an example of a single card using the shortcode in a template file."]');
                ?>
            </div>
            
            <div style="margin-bottom: 40px;">
                <h3>Example 2: Multiple Cards in Container</h3>
                <?php 
                // Display multiple cards in a container
                echo do_shortcode('[opg_cards_container]
                    [opg_card 
                        image="' . get_template_directory_uri() . '/images/about-us.jpg.jpeg' . '" 
                        label="Property" 
                        title="Modern Living" 
                        content="Comfortable and stylish living space in a prime location."]
                    [opg_card 
                        image="' . get_template_directory_uri() . '/images/BEYOND%20THE%205%20BASIC%20STRATEGIES%20TO%20MANAGE%20REPAIR%20AND%20MAINTENANCE%20EXPENSES.jpg.jpeg' . '" 
                        label="Service" 
                        title="Property Management" 
                        content="Professional property management services tailored to your needs."]
                    [opg_card 
                        image="' . get_template_directory_uri() . '/images/apartment-turnover-service.png' . '" 
                        label="Maintenance" 
                        title="Regular Upkeep" 
                        content="Keeping your property in excellent condition year-round."]
                [/opg_cards_container]');
                ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
