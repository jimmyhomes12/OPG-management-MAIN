<?php
/**
 * Custom shortcodes for the OPG theme
 *
 * @package OPG-theme
 */

if (!function_exists('opg_card_shortcode')) {
    /**
     * Shortcode for displaying a card
     * 
     * Usage: [opg_card image="path/to/image.jpg" label="Featured" title="Card Title" content="Card content goes here"]
     *
     * @param array $atts Shortcode attributes
     * @return string HTML output
     */
    function opg_card_shortcode($atts) {
        $atts = shortcode_atts(
            array(
                'image'   => '',
                'alt'     => '',
                'label'   => 'Featured',
                'title'   => '',
                'content' => '',
            ),
            $atts,
            'opg_card'
        );
        
        // Start output buffering
        ob_start();
        
        // Prepare args for template part
        $args = array(
            'image_url' => $atts['image'],
            'alt_text'  => $atts['alt'] ? $atts['alt'] : $atts['title'],
            'label'     => $atts['label'],
            'title'     => $atts['title'],
            'content'   => $atts['content'],
        );
        
        // Get the template part
        get_template_part('template-parts/card', null, $args);
        
        // Return the buffered content
        return ob_get_clean();
    }
}
add_shortcode('opg_card', 'opg_card_shortcode');

if (!function_exists('opg_cards_container_shortcode')) {
    /**
     * Shortcode for creating a cards container
     * 
     * Usage: 
     * [opg_cards_container]
     *   [opg_card image="path/to/image1.jpg" title="Card 1" content="Content 1"]
     *   [opg_card image="path/to/image2.jpg" title="Card 2" content="Content 2"]
     * [/opg_cards_container]
     *
     * @param array $atts Shortcode attributes
     * @param string $content Shortcode content
     * @return string HTML output
     */
    function opg_cards_container_shortcode($atts, $content = null) {
        // Process the content (this will process nested shortcodes)
        $content = do_shortcode($content);
        
        // Return the content wrapped in a cards-container div
        return '<div class="cards-container">' . $content . '</div>';
    }
}
add_shortcode('opg_cards_container', 'opg_cards_container_shortcode');
