<?php
/**
 * Creates required pages for the theme
 *
 * @package OPG-theme
 */

/**
 * Create the Tips and Tricks page if it doesn't exist
 */
function opg_create_tips_and_tricks_page() {
    // Check if the page already exists
    $page_exists = get_page_by_path('tips-and-tricks');
    
    // If the page doesn't exist, create it
    if (!$page_exists) {
        // Create the page
        $tips_page = array(
            'post_title'    => 'Tips and Tricks for Owners & Tenants',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_name'     => 'tips-and-tricks',
            'page_template' => 'page-tips-and-tricks.php'
        );
        
        // Insert the page into the database
        $page_id = wp_insert_post($tips_page);
        
        if ($page_id) {
            // Set the page template
            update_post_meta($page_id, '_wp_page_template', 'page-tips-and-tricks.php');
        }
    }
}

// Run this function on theme activation
add_action('after_switch_theme', 'opg_create_tips_and_tricks_page');

/**
 * Create the Tips and Tricks page when this file is included
 * This will create the page immediately without waiting for theme activation
 */
function opg_create_pages_now() {
    opg_create_tips_and_tricks_page();
}

// Create pages immediately (when in admin area)
if (is_admin()) {
    add_action('init', 'opg_create_pages_now');
}
