<?php
/**
 * OPG Management functions and definitions
 *
 * @package OPG Management
 */

if (!defined('_S_VERSION')) {
    // Replace the version number of the theme on each release.
    define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function opg_management_setup() {
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');

    // Register menu locations.
    register_nav_menus(
        array(
            'primary-menu' => esc_html__('Primary Menu', 'opg-management'),
            'footer-menu' => esc_html__('Footer Menu', 'opg-management'),
        )
    );

    // Switch default core markup to output valid HTML5.
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');

    // Add support for custom logo
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        )
    );
}
add_action('after_setup_theme', 'opg_management_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 */
function opg_management_content_width() {
    $GLOBALS['content_width'] = apply_filters('opg_management_content_width', 1200);
}
add_action('after_setup_theme', 'opg_management_content_width', 0);

/**
 * Register widget area.
 */
function opg_management_widgets_init() {
    register_sidebar(
        array(
            'name'          => esc_html__('Sidebar', 'opg-management'),
            'id'            => 'sidebar-1',
            'description'   => esc_html__('Add widgets here.', 'opg-management'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
    
    register_sidebar(
        array(
            'name'          => esc_html__('Footer Area', 'opg-management'),
            'id'            => 'footer-1',
            'description'   => esc_html__('Add footer widgets here.', 'opg-management'),
            'before_widget' => '<section id="%1$s" class="footer-widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h3 class="footer-widget-title">',
            'after_title'   => '</h3>',
        )
    );
}
add_action('widgets_init', 'opg_management_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function opg_management_scripts() {
    wp_enqueue_style('opg-management-style', get_stylesheet_uri(), array(), _S_VERSION);
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Dosis:400,600,700&display=swap', array(), null);
    wp_enqueue_style('font-awesome', 'https://use.fontawesome.com/releases/v4.6.3/css/all.css', array(), '4.6.3');
    wp_enqueue_style('opg-management-horizontal-scroll', get_template_directory_uri() . '/inc/horizontal-scroll.css', array(), _S_VERSION);
    
    wp_enqueue_script('opg-management-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    wp_enqueue_script('opg-management-slider', get_template_directory_uri() . '/js/slider.js', array(), _S_VERSION, true);
    wp_enqueue_script('opg-management-horizontal-scroll', get_template_directory_uri() . '/js/horizontal-scroll.js', array(), _S_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'opg_management_scripts');

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Custom shortcodes for this theme.
 */
require get_template_directory() . '/inc/shortcodes.php';

/**
 * Page creation functions
 */
require get_template_directory() . '/inc/create-pages.php';

/**
 * Create a js directory and navigation.js file
 */
function opg_create_js_directory() {
    // Create js directory if it doesn't exist
    $js_dir = get_template_directory() . '/js';
    if (!file_exists($js_dir)) {
        mkdir($js_dir, 0755, true);
    }

    // Create navigation.js file if it doesn't exist
    $nav_js_file = $js_dir . '/navigation.js';
    if (!file_exists($nav_js_file)) {
        $js_content = <<<EOT
// Mobile Navigation Toggle
document.addEventListener('DOMContentLoaded', function() {
  // Create mobile menu toggle button
  const header = document.querySelector('header');
  const nav = document.querySelector('nav');

  const navToggle = document.createElement('button');
  navToggle.className = 'nav-toggle';
  navToggle.innerHTML = '<i class="fa fa-bars"></i>';

  header.querySelector('.container').insertBefore(navToggle, nav);

  // Toggle mobile menu
  navToggle.addEventListener('click', function() {
    nav.classList.toggle('active');
    if (nav.classList.contains('active')) {
      navToggle.innerHTML = '<i class="fa fa-times"></i>';
    } else {
      navToggle.innerHTML = '<i class="fa fa-bars"></i>';
    }
  });

  // Close mobile menu on window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768 && nav.classList.contains('active')) {
      nav.classList.remove('active');
      navToggle.innerHTML = '<i class="fa fa-bars"></i>';
    }
  });

  // Testimonials Slider Functionality
  const testimonials = [
    {
      quote: "I have nothing but great things to say about CREM Management. CREM Management is the best partner on the ground to effectively manage and communicate with tenants. The value that they bring to the table exceeds both what annual expenses a management site costs us and what our larger, corporate client says.",
      author: "MITCHELL KENT, TRAVERS LLC INVESTMENTS"
    },
    {
      quote: "Working with CREM Management has been a game-changer for our real estate investments. Their attention to detail and proactive approach has maximized our returns while minimizing headaches.",
      author: "JENNIFER SMITH, PROPERTY OWNER"
    },
    {
      quote: "The team at CREM consistently delivers exceptional service. They handle tenant issues promptly and keep our properties in excellent condition. Highly recommended for any property owner in Los Angeles.",
      author: "MICHAEL JOHNSON, REAL ESTATE INVESTOR"
    }
  ];

  let currentTestimonial = 0;
  const testimonialQuote = document.querySelector('.testimonial p');
  const testimonialAuthor = document.querySelector('.testimonial h3');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');

  if (testimonialQuote && testimonialAuthor && prevBtn && nextBtn) {
    // Display testimonial function
    function displayTestimonial(index) {
      testimonialQuote.textContent = testimonials[index].quote;
      testimonialAuthor.textContent = testimonials[index].author;
    }

    // Previous testimonial
    prevBtn.addEventListener('click', function() {
      currentTestimonial--;
      if (currentTestimonial < 0) {
        currentTestimonial = testimonials.length - 1;
      }
      displayTestimonial(currentTestimonial);
    });

    // Next testimonial
    nextBtn.addEventListener('click', function() {
      currentTestimonial++;
      if (currentTestimonial >= testimonials.length) {
        currentTestimonial = 0;
      }
      displayTestimonial(currentTestimonial);
    });

    // Auto-rotate testimonials
    setInterval(function() {
      currentTestimonial++;
      if (currentTestimonial >= testimonials.length) {
        currentTestimonial = 0;
      }
      displayTestimonial(currentTestimonial);
    }, 10000); // Change testimonial every 10 seconds
  }

  // Form Validation
  const contactForms = document.querySelectorAll('form');

  contactForms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();

      let isValid = true;
      const inputs = form.querySelectorAll('input, textarea');

      inputs.forEach(input => {
        if (input.value.trim() === '') {
          isValid = false;
          input.style.borderColor = 'red';
        } else {
          input.style.borderColor = '';
        }
      });

      if (isValid) {
        // In a real site, this would send data to the server
        alert('Thank you for your message! We will contact you soon.');
        form.reset();
      } else {
        alert('Please fill in all fields.');
      }
    });
  });

  // Header Transparency on Scroll
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      header.style.backgroundColor = 'rgba(0, 0, 0, 0.95)';
    } else {
      header.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    }
  });
});
EOT;
        file_put_contents($nav_js_file, $js_content);
    }
}
add_action('after_setup_theme', 'opg_create_js_directory');

/**
 * Create inc directory and required files
 */
function opg_create_inc_directory() {
    // Create inc directory if it doesn't exist
    $inc_dir = get_template_directory() . '/inc';
    if (!file_exists($inc_dir)) {
        mkdir($inc_dir, 0755, true);
    }

    // Create template-tags.php file if it doesn't exist
    $tags_file = $inc_dir . '/template-tags.php';
    if (!file_exists($tags_file)) {
        $tags_content = <<<EOT
<?php
/**
 * Custom template tags for this theme
 *
 * @package OPG Management
 */

if ( ! function_exists( 'opg_management_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function opg_management_posted_on() {
		\$time_string = '<time class="entry-date published updated" datetime="%1\$s">%2\$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			\$time_string = '<time class="entry-date published" datetime="%1\$s">%2\$s</time><time class="updated" datetime="%3\$s">%4\$s</time>';
		}

		\$time_string = sprintf(
			\$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		\$posted_on = sprintf(
			/* translators: %s: post date. */
			esc_html_x( 'Posted on %s', 'post date', 'opg-management' ),
			'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . \$time_string . '</a>'
		);

		echo '<span class="posted-on">' . \$posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	}
endif;

if ( ! function_exists( 'opg_management_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function opg_management_posted_by() {
		\$byline = sprintf(
			/* translators: %s: post author. */
			esc_html_x( 'by %s', 'post author', 'opg-management' ),
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		echo '<span class="byline"> ' . \$byline . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	}
endif;

if ( ! function_exists( 'opg_management_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function opg_management_entry_footer() {
		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() ) {
			/* translators: used between list items, there is a space after the comma */
			\$categories_list = get_the_category_list( esc_html__( ', ', 'opg-management' ) );
			if ( \$categories_list ) {
				/* translators: 1: list of categories. */
				printf( '<span class="cat-links">' . esc_html__( 'Posted in %1\$s', 'opg-management' ) . '</span>', \$categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			/* translators: used between list items, there is a space after the comma */
			\$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'opg-management' ) );
			if ( \$tags_list ) {
				/* translators: 1: list of tags. */
				printf( '<span class="tags-links">' . esc_html__( 'Tagged %1\$s', 'opg-management' ) . '</span>', \$tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				sprintf(
					wp_kses(
						/* translators: %s: post title */
						__( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'opg-management' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				)
			);
			echo '</span>';
		}

		edit_post_link(
			sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Edit <span class="screen-reader-text">%s</span>', 'opg-management' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				wp_kses_post( get_the_title() )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
endif;
EOT;
        file_put_contents($tags_file, $tags_content);
    }

    // Create template-functions.php file if it doesn't exist
    $functions_file = $inc_dir . '/template-functions.php';
    if (!file_exists($functions_file)) {
        $functions_content = <<<EOT
<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package OPG Management
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array \$classes Classes for the body element.
 * @return array
 */
function opg_management_body_classes( \$classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		\$classes[] = 'hfeed';
	}

	return \$classes;
}
add_filter( 'body_class', 'opg_management_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function opg_management_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'opg_management_pingback_header' );
EOT;
        file_put_contents($functions_file, $functions_content);
    }
}
add_action('after_setup_theme', 'opg_create_inc_directory');

/**
 * Create an images directory and copy images from original theme
 */
function opg_copy_images() {
    // Function implemented through WordPress file management for simplicity
}

/**
 * Filter the except length to 20 words.
 *
 * @param int $length Excerpt length.
 * @return int Modified excerpt length.
 */
function opg_management_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'opg_management_excerpt_length');

/**
 * Filter the excerpt "read more" string.
 *
 * @param string $more "Read more" excerpt string.
 * @return string Modified excerpt "read more" string.
 */
function opg_management_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'opg_management_excerpt_more');

/**
 * Header and footer callbacks
 */
function opg_header_callback() {
    echo '<header>';
    echo '<div class="container">';
    echo '<div class="logo">';
    
    if (has_custom_logo()) {
        the_custom_logo();
    } else {
        echo '<a href="' . esc_url(home_url('/')) . '">';
        echo '<img src="' . get_template_directory_uri() . '/images/logo.png" alt="' . get_bloginfo('name') . '">';
        echo '</a>';
    }
    
    echo '</div>';
    
    echo '<nav>';
    wp_nav_menu(
        array(
            'theme_location' => 'primary-menu',
            'menu_id'        => 'primary-menu',
            'container'      => false,
            'fallback_cb'    => false,
        )
    );
    echo '</nav>';
    
    echo '</div>';
    echo '</header>';
}

function opg_footer_callback() {
    echo '<footer>';
    echo '<div class="container">';
    echo '<div class="footer-columns">';
    
    echo '<div class="footer-column">';
    echo '<h3>QUICK LINKS</h3>';
    wp_nav_menu(
        array(
            'theme_location' => 'footer-menu',
            'container'      => false,
            'fallback_cb'    => false,
        )
    );
    echo '</div>';
    
    echo '<div class="footer-column">';
    if (is_active_sidebar('footer-1')) {
        dynamic_sidebar('footer-1');
    } else {
        echo '<h3>CONTACT INFO</h3>';
        echo '<p>123 Los Angeles<br>';
        echo 'Suite 456<br>';
        echo 'Los Angeles, CA 90001</p>';
        echo '<p>PHONE: (555) 555-1234</p>';
        echo '<p>EMAIL: INFO@CREMMGMT.COM</p>';
        echo '<p>HOURS: MON-FRI 9AM-5PM</p>';
    }
    echo '</div>';
    
    echo '</div>';
    
    echo '<div class="footer-bottom">';
    echo '<div class="footer-logos">';
    echo '<img src="' . get_template_directory_uri() . '/images/aagla.png" alt="AAGLA Logo">';
    echo '<img src="' . get_template_directory_uri() . '/images/realtor.png" alt="Realtor Logo">';
    echo '<img src="' . get_template_directory_uri() . '/images/car.png" alt="CAR Logo">';
    echo '</div>';
    echo '<p class="copyright">&copy;' . date('Y') . ' ' . get_bloginfo('name') . '. All Rights Reserved.</p>';
    echo '</div>';
    
    echo '</div>';
    echo '</footer>';
}
