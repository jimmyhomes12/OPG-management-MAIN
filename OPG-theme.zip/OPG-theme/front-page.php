<?php

/**
 * The template for displaying the front page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package OPG_Management
 */

get_header();
?>

<!-- Hero Section with Slider -->
<section class="hero">
  <div class="slideshow-container">
    <div class="slide fade" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/BG Slide 1.jpg')"></div>
    <div class="slide fade" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/BG Slide 2.jpg')"></div>
    <div class="slide fade" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/BG Slide 3.jpg')"></div>
    <!-- Semi-transparent overlay -->
    <div class="slide-overlay"></div>

    <!-- Navigation dots -->
    <div class="dots-container">
      <span class="dot"></span>
      <span class="dot"></span>
      <span class="dot"></span>
    </div>
  </div>
  <div class="hero-text">
    <p class="subtitle">LOS ANGELES AND ORANGE COUNTY PROPERTY MANAGEMENT SERVICES ELEVATED</p>
    <h1>MAXIMIZING VALUE. MINIMIZING LIABILITY.</h1>
    <div class="hero-buttons">
      <a href="#" class="btn primary-btn">GET STARTED TODAY</a>
      <a href="#" class="btn secondary-btn">VIEW VACANCIES</a>
    </div>
  </div>
</section>

<!-- About Section -->
<section class="about">
  <div class="container">
    <div class="about-content">
      <div class="about-image">
        <img src="<?php echo get_template_directory_uri(); ?>/images/about-us.jpg.jpeg" alt="Office Interior">
      </div>
      <div class="about-text">
        <h2>ABOUT US</h2>
        <h3>CREM IS A FULL-SERVICE LOS ANGELES AND ORANGE COUNTY PROPERTY MANAGEMENT COMPANY</h3>
        <p>"CREM Property Management" was created with the vision, passion and oversight of real estate assets both residential and commercial. Our mission is simple - maximize property values and investment returns.</p>
        <p>This is what separates CREM from everyone from the rest. We are driven to find ways to reduce expenditures, expand leasing efforts, protecting rental revenue, and creating exceptional living environments for residents.</p>
      </div>
    </div>
  </div>
</section>

<!-- Management Services Section -->
<section class="services">
  <div class="container">
    <h2>MANAGEMENT SERVICES</h2>
    <h3>OWNERSHIP WITHOUT THE HASSLE</h3>
    <div class="services-grid">
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/rent-collection.png" alt="Rent Invoicing" class="service-icon">
        <h4>RENT INVOICING</h4>
        <p>In order to stay on top of rent payments, we send monthly invoices via email setting a standard framework of charges to avoid confusion and late payments.</p>
      </div>
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/rent-collection.png" alt="Rent Collection" class="service-icon">
        <h4>RENT COLLECTION</h4>
        <p>Tenants can pay their rent online at any time via direct deposit. Through this technology, we are automatically informed of any late payments, and can thus address them immediately.</p>
      </div>
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/expenses.png" alt="Expenses" class="service-icon">
        <h4>EXPENSES</h4>
        <p>We pay all vendors on behalf of the property on time and with ease, and make sure that invoices are automatically assigned to the correct property so there are no billing confusion or errors.</p>
      </div>
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/financial-reporting.png" alt="Financial Reporting" class="service-icon">
        <h4>FINANCIAL REPORTING</h4>
        <p>Running a property is no different than running a business; we provide owners with up-to-date financial statements and other reports customized to meet your property management needs.</p>
      </div>
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/repair-maintenance.png" alt="Repair & Maintenance" class="service-icon">
        <h4>REPAIR & MAINTENANCE</h4>
        <p>Quality of improvements and organization are the hallmarks of our work on all repairs or renovations; we ensure your property is getting the proper attention and care it needs to flourish.</p>
      </div>
      <div class="service-item">
        <img src="<?php echo get_template_directory_uri(); ?>/images/apartment-turnover-service.png" alt="Apartment Turnover Services" class="service-icon">
        <h4>APARTMENT TURNOVER SERVICES</h4>
        <p>After a tenant vacifies and you want to relist, we help by overseeing the entire unit turnover and renovation process, ensuring it's ready for the next tenant in a timely manner.</p>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="cta">
  <div class="container">
    <h2>TIRED OF SELF-MANAGEMENT?</h2>
    <a href="#" class="btn primary-btn">LET'S TALK</a>
  </div>
</section>

<!-- Vacancies Section -->
<section class="vacancies">
  <div class="container">
    <h2>VACANCIES</h2>
    <div class="vacancies-search">
      <div class="search-fields">
        <select>
          <option>All</option>
          <option>Studio</option>
          <option>1 Bedroom</option>
          <option>2 Bedroom</option>
          <option>3+ Bedroom</option>
        </select>
      </div>
      <button class="filter-btn">FILTER</button>
    </div>
    <div class="vacancies-listings">
      <h3>Current Listings</h3>
      <p>We currently have no available properties for rent. Search Again</p>
    </div>
  </div>
</section>

<!-- Contact Section -->
<section class="contact">
  <div class="container">
    <div class="contact-info">
      <h2>GET IN TOUCH</h2>
      <p>Tell us what about your real estate management needs.</p>
    </div>
    <div class="contact-form">
      <h2>LEAVE A MESSAGE</h2>
      <form>
        <div class="form-group">
          <input type="text" placeholder="First & Last Name">
        </div>
        <div class="form-group">
          <input type="email" placeholder="Email">
        </div>
        <div class="form-group">
          <input type="tel" placeholder="Phone">
        </div>
        <div class="form-group">
          <textarea placeholder="Describe your property needs"></textarea>
        </div>
        <button type="submit" class="submit-btn">SUBMIT</button>
      </form>
    </div>

  </div>
</section>

<!-- News Section -->
<section class="news">
  <div class="container">
    <h2>LATEST NEWS</h2>
    <p class="news-subtitle">TIPS AND TRICKS FOR OWNERS & TENANTS ALIKE</p>
    <div class="news-grid">
      <?php
      $args = array(
        'post_type'      => 'post',
        'posts_per_page' => 10,
      );
      $query = new WP_Query($args);

      if ($query->have_posts()) :
        while ($query->have_posts()) :
          $query->the_post();
      ?>
          <div class="news-item">
            <?php if (has_post_thumbnail()) : ?>
              <?php the_post_thumbnail('large'); ?>
            <?php else : ?>
              <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php the_title_attribute(); ?>">
            <?php endif; ?>
            <h3><?php the_title(); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo get_the_category_list(', '); ?></span>
              <span class="date"><?php echo get_the_date(); ?></span>
            </div>
            <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
          </div>
        <?php
        endwhile;
        wp_reset_postdata();
      else :
        // Create an array of 10 property management tips
        $tips = array(
          array(
            'title' => 'Understand Your Lease Agreement',
            'category' => 'Legal',
            'description' => 'Take time to thoroughly read and understand all terms in your lease agreement to avoid future misunderstandings.'
          ),
          array(
            'title' => 'Keep Detailed Records of Property Interactions',
            'category' => 'Organization',
            'description' => 'Track all maintenance requests, payments, and communication to keep things organized and avoid disputes down the line.'
          ),
          array(
            'title' => 'Set Clear Expectations',
            'category' => 'Communication',
            'description' => 'Ensure both landlords and tenants understand their responsibilities regarding maintenance, repairs, and property rules.'
          ),
          array(
            'title' => 'Regular Maintenance Saves Money',
            'category' => 'Maintenance',
            'description' => 'Preventative maintenance is more cost-effective than emergency repairs - address small issues before they become big problems.'
          ),
          array(
            'title' => 'Know Your Rights and Responsibilities',
            'category' => 'Legal',
            'description' => 'Both landlords and tenants should be familiar with local rental laws and regulations that affect their rights and obligations.'
          ),
          array(
            'title' => 'Document Property Condition',
            'category' => 'Documentation',
            'description' => 'Take detailed photos before move-in and after move-out to document property condition and avoid security deposit disputes.'
          ),
          array(
            'title' => 'Establish Good Communication',
            'category' => 'Relationships',
            'description' => 'Open, respectful communication between owners and tenants creates a positive rental experience for everyone involved.'
          ),
          array(
            'title' => 'Respond Promptly to Maintenance Requests',
            'category' => 'Service',
            'description' => 'Quick responses to maintenance issues show respect for tenants and help prevent minor problems from escalating.'
          ),
          array(
            'title' => 'Consider Professional Property Management',
            'category' => 'Management',
            'description' => 'Professional managers can save owners time, reduce stress, and often bring expertise that improves property performance.'
          ),
          array(
            'title' => 'Plan for Property Upgrades',
            'category' => 'Investment',
            'description' => 'Strategic improvements can increase property value, attract better tenants, and justify higher rents.'
          )
        );

        // Display the tips as news items
        foreach ($tips as $tip) :
        ?>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
          <div class="news-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/banner-1.jpg.jpeg" alt="<?php echo esc_attr($tip['title']); ?>">
            <h3><?php echo esc_html($tip['title']); ?></h3>
            <div class="news-meta">
              <span class="category"><?php echo esc_html($tip['category']); ?></span>
              <span class="date"><?php echo date('F j, Y'); ?></span>
            </div>
            <p><?php echo esc_html($tip['description']); ?></p>
            <a href="#" class="read-more">Read More</a>
          </div>
      <?php
        endforeach;
      endif;
      ?>
    </div>
  </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials">
  <div class="container">
    <h2>WHAT CLIENTS SAY</h2>
    <div class="testimonial-wrapper">
      <div class="testimonial">
        <p>"I have nothing but great things to say about CREM Management. CREM Management is the best partner on the ground to effectively manage and communicate with tenants. The value that they bring to the table exceeds both what annual expenses a management site costs us and what our larger, corporate client says."</p>
        <h3>MITCHELL KENT, TRAVERS LLC INVESTMENTS</h3>
      </div>
    </div>
    <div class="testimonial-nav">
      <button class="prev-btn"><img src="<?php echo get_template_directory_uri(); ?>/images/arrow-left.png" alt="Previous"></button>
      <button class="next-btn"><img src="<?php echo get_template_directory_uri(); ?>/images/arrow-right.png" alt="Next"></button>
    </div>
  </div>
</section>

<!-- Contact Form Section -->
<section class="contact-form-footer">
  <div class="container">
    <h2>CONTACT US</h2>
    <?php echo do_shortcode('[contact-form-7 id="123" title="Contact Form"]'); ?>
  </div>
</section>

<?php
get_footer();
?>